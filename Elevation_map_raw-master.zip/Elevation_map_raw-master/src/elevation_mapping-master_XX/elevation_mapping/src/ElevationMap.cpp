/*
 * ElevationMap.cpp
 *
 *  Created on: Feb 5, 2014
 *      Author: Péter Fankhauser
 *	 Institute: ETH Zurich, ANYbotics
 */

#include "elevation_mapping/ElevationMap.hpp"

// Elevation Mapping
#include "elevation_mapping/ElevationMapFunctors.hpp"
#include "elevation_mapping/WeightedEmpiricalCumulativeDistributionFunction.hpp"

// Grid Map
#include <grid_map_msgs/GridMap.h>

// PCL
#include <pcl/conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/PCLPointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/common/transforms.h>	
// Math
#include <math.h>

// ROS Logging
#include <ros/ros.h>

// Eigen
#include <Eigen/Dense>

#include <opencv2/highgui/highgui.hpp>
#include <cv_bridge/cv_bridge.h>

using namespace std;
using namespace grid_map;


namespace elevation_mapping {

ElevationMap::ElevationMap(ros::NodeHandle nodeHandle)
    : nodeHandle_(nodeHandle),
      visualMap_({"elevation", "variance", "rough", "slope", "traver"}),
     
      hasUnderlyingMap_(false),
      visibilityCleanupDuration_(0.0)
{
  rawMap_.setBasicLayers({"elevation"});
  rawMap2_.setBasicLayers({"elevation"});
  visualMap_.setBasicLayers({"elevation"});

  
  clear();

  visualMapPublisher_ = nodeHandle_.advertise<grid_map_msgs::GridMap>("visual_map", 1);
  elevationMapRawPublisher_ = nodeHandle_.advertise<grid_map_msgs::GridMap>("elevation_map_raw", 1);
  obstaclePublisher_ = nodeHandle_.advertise<sensor_msgs::PointCloud2>("obstaclepoints",1);
  imagePublisher_ = nodeHandle_.advertise<sensor_msgs::Image>("elevation_image", 1);
  initialTime_ = ros::Time::now();
}

ElevationMap::~ElevationMap()
{
}

void ElevationMap::setGeometry(const grid_map::Length& length, const double& resolution, const grid_map::Position& position)
{

  visualMap_.setGeometry(length, resolution, position);
  
  //ROS_INFO_STREAM("Elevation map grid resized to " << rawMap_.getSize()(0) << " rows and "  << rawMap_.getSize()(1) << " columns.");
  //std::cout << "ElevationMap::setGeometry unlock" <<std::endl;
}

void ElevationMap::show(int length, float *elevation, float*var, float *rough, float *slope, float *traver)
{
  //std::cout << "cleanareacleanmap frame is:" << cleanareaMap_.getFrameId() << std::endl;

  //std::cout << "update points num:"<<pointCloud->size() << std::endl; 
  //cleanareaclean();
  cv::Mat image = cv::Mat::zeros(length, length, CV_8UC1);
  visualMap_.clearAll();
  obstacle_pointCloud.points.clear();
  int index, index_x, index_y;
  pcl::PointXYZRGB point_obstacle;
  Index start_index = visualMap_.getStartIndex();

  

  for (GridMapIterator iterator(visualMap_); !iterator.isPastEnd(); ++iterator) {
    index_x = (*iterator).transpose().x();
    index_y = (*iterator).transpose().y();
    index = index_x * length + index_y;
    if(elevation[index] != -10)
    {

      visualMap_.at("elevation", *iterator) = elevation[index];
      visualMap_.at("variance", *iterator) = var[index];
      visualMap_.at("rough", *iterator) = rough[index];
      visualMap_.at("slope", *iterator) = slope[index];
      visualMap_.at("traver", *iterator) = traver[index];
      if(visualMap_.at("traver", *iterator) < 0.75)
        visualMap_.at("traver", *iterator) = 0;
      else
        visualMap_.at("traver", *iterator) = 1;
      // if(1)
      // {
      //   Position point;
      //   visualMap_.getPosition(*iterator, point);
      //   point_obstacle.x = point.x();
      //   point_obstacle.y = point.y();
      //   point_obstacle.z = visualMap_.at("elevation", *iterator);
      //   obstacle_pointCloud.push_back(point_obstacle);
        
      // }
    }
    
  }

  // obstacle_pointCloud.header.frame_id = "map";
  // pcl_conversions::toPCL(ros::Time::now(), obstacle_pointCloud.header.stamp);
 
  // std::cout << "obstacle point num:" << obstacle_pointCloud.size() << std::endl;
  // if(obstacle_pointCloud.size() > 0)
  // {
  //   sensor_msgs::PointCloud2 pub_pointcloud;
  //   pcl::toROSMsg(obstacle_pointCloud, pub_pointcloud);
  //   obstaclePublisher_.publish(pub_pointcloud); 
  // }


  grid_map_msgs::GridMap message;
  GridMapRosConverter::toMessage(visualMap_, message);
  visualMapPublisher_.publish(message);
}




bool ElevationMap::clear()
{

  rawMap_.clearAll();
  rawMap_.resetTimestamp();
  rawMap2_.clearAll();
  rawMap2_.resetTimestamp();
  visualMap_.clearAll();
  visualMap_.resetTimestamp();
  //std::cout << "ElevationMap::clear unlock" <<std::endl;
  return true;
}




void ElevationMap::move(const Index M_startindex, Position M_position)
{
  visualMap_.setStartIndex(M_startindex);
  visualMap_.setPosition(M_position);
  //rawMap_.setPosition(M_position);
}

grid_map::GridMap& ElevationMap::getRawGridMap()
{
  return rawMap_;
}


ros::Time ElevationMap::getTimeOfLastUpdate()
{
  return ros::Time().fromNSec(rawMap_.getTimestamp());
}



const kindr::HomTransformQuatD& ElevationMap::getPose()
{
  return pose_;
}



void ElevationMap::setFrameId(const std::string& frameId)
{
  visualMap_.setFrameId(frameId);
}

const std::string& ElevationMap::getFrameId()
{
  return visualMap_.getFrameId();
}



} /* namespace */
