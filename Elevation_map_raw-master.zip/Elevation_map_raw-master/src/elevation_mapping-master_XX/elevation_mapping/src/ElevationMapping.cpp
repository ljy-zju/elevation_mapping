/*
 * ElevationMapping.cpp
 *
 *  Created on: Nov 12, 2013
 *      Author: Péter Fankhauser
 *	 Institute: ETH Zurich, ANYbotics
 */
#include "elevation_mapping/ElevationMapping.hpp"

#include <thread>

// Elevation Mapping
#include "elevation_mapping/ElevationMap.hpp"
#include "elevation_mapping/sensor_processors/StructuredLightSensorProcessor.hpp"
#include "elevation_mapping/sensor_processors/StereoSensorProcessor.hpp"
#include "elevation_mapping/sensor_processors/LaserSensorProcessor.hpp"
#include "elevation_mapping/sensor_processors/PerfectSensorProcessor.hpp"
#include "elevation_mapping/Pointcloudtogrid.hpp"

// Grid Map
#include <grid_map_ros/grid_map_ros.hpp>
#include <grid_map_msgs/GridMap.h>

//multi threads
#include <cstdlib>
#include <pthread.h>
#include <unistd.h>

// PCL
#include <pcl/io/pcd_io.h>
#include <pcl/conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/PCLPointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/passthrough.h>

#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/Image.h>

// opencv
#include <opencv2/highgui/highgui.hpp>
#include <cv_bridge/cv_bridge.h>

// Kindr
#include <kindr/Core>
#include <kindr_ros/kindr_ros.hpp>

// Boost
#include <boost/bind.hpp>
#include <boost/thread/recursive_mutex.hpp>

// STL
#include <string>
#include <math.h>
#include <limits>

using namespace std;
using namespace grid_map;
using namespace ros;
using namespace tf;
using namespace pcl;
using namespace kindr;
using namespace kindr_ros;


void Move(float *current_Position, float resolution, int length, float *h_central_coordinate, int *h_start_indice);
void Init_GPU_elevationmap(int length, float resolution, float h_mahalanobisDistanceThreshold_, float h_obstacle_threshold);

void Raytracing(int length_);
void Fuse(int length, int point_num, int *point_index, float *point_height, float *point_var);
void Map_feature(int length, float *elevation, float *var, float *rough, float *slope, float *traver);

namespace elevation_mapping {

class ElevationMapping;


ElevationMapping::ElevationMapping(ros::NodeHandle& nodeHandle)
    : nodeHandle_(nodeHandle),
      map_(nodeHandle),
      robotMotionMapUpdater_(nodeHandle),
      isContinouslyFusing_(false),
      ignoreRobotMotionUpdates_(false)
{
  ROS_INFO("Elevation mapping node started.");

  readParameters();

  pointCloudSubscriber_ = nodeHandle_.subscribe(pointCloudTopic_, 1, &ElevationMapping::pointCloudCallback, this);


  /*
  
  message_filters::Subscriber<sensor_msgs::PointCloud2> vel_sub(nodeHandle, pointCloudTopic_, 1);
  message_filters::Subscriber<sensor_msgs::Image> image_sub(nodeHandle_, imageTopic_, 1);

  typedef message_filters::sync_policies::ApproximateTime<sensor_msgs::PointCloud2, sensor_msgs::Image> MySyncPolicy;
  message_filters::Synchronizer<MySyncPolicy> sync(MySyncPolicy(1000), vel_sub, image_sub);
  sync.registerCallback(boost::bind(&ElevationMapping::pointCloudCallback, this, _1, _2));
  */


  //rgbdSubscriber_ = nodeHandle_.subscribe("/camera/depth/image", 1, &ElevationMapping::rgbdCallback, this);
  if (!robotPoseTopic_.empty()) {
    robotPoseSubscriber_.subscribe(nodeHandle_, robotPoseTopic_, 1);
    robotPoseCache_.connectInput(robotPoseSubscriber_);
    robotPoseCache_.setCacheSize(robotPoseCacheSize_);
  } else {
    ignoreRobotMotionUpdates_ = true;
  }
  

  initialize();
}

ElevationMapping::~ElevationMapping()
{
  
  nodeHandle_.shutdown();
  
}

bool ElevationMapping::readParameters()
{
  // ElevationMapping parameters.
  nodeHandle_.param("point_cloud_topic", pointCloudTopic_, string("/points"));
  nodeHandle_.param("robot_pose_with_covariance_topic", robotPoseTopic_, string("/pose"));
  nodeHandle_.param("track_point_frame_id", trackPointFrameId_, string("/robot"));
  nodeHandle_.param("track_point_x", trackPoint_.x(), 0.0);
  nodeHandle_.param("track_point_y", trackPoint_.y(), 12.0);
  nodeHandle_.param("track_point_z", trackPoint_.z(), 0.0);

  nodeHandle_.param("robot_pose_cache_size", robotPoseCacheSize_, 200);
  ROS_ASSERT(robotPoseCacheSize_ >= 0);

  double minUpdateRate;
  nodeHandle_.param("min_update_rate", minUpdateRate, 2.0);
  maxNoUpdateDuration_.fromSec(1.0 / minUpdateRate);
  ROS_ASSERT(!maxNoUpdateDuration_.isZero());

  double timeTolerance;
  nodeHandle_.param("time_tolerance", timeTolerance, 0.0);
  timeTolerance_.fromSec(timeTolerance);
  
   

  // ElevationMap parameters. TODO Move this to the elevation map class.
  string frameId;
  nodeHandle_.param("map_frame_id", frameId, string("/map"));
  map_.setFrameId(frameId);

  grid_map::Length length;
  grid_map::Position position;
  double resolution;
  nodeHandle_.param("length_in_x", length(0), 1.5);
  nodeHandle_.param("length_in_y", length(1), 1.5);
  nodeHandle_.param("position_x", position.x(), 0.0);
  nodeHandle_.param("position_y", position.y(), 0.0);
  nodeHandle_.param("resolution", resolution, 0.01);
  map_.setGeometry(length, resolution, position);
  

  nodeHandle_.param("min_variance", map_.minVariance_, pow(0.003, 2));
  nodeHandle_.param("max_variance", map_.maxVariance_, pow(0.03, 2));
  nodeHandle_.param("mahalanobis_distance_threshold", map_.mahalanobisDistanceThreshold_, 2.5);
  nodeHandle_.param("multi_height_noise", map_.multiHeightNoise_, pow(0.003, 2));
  nodeHandle_.param("min_horizontal_variance", map_.minHorizontalVariance_, pow(resolution / 2.0, 2)); // two-sigma
  nodeHandle_.param("max_horizontal_variance", map_.maxHorizontalVariance_, 0.5);
  nodeHandle_.param("underlying_map_topic", map_.underlyingMapTopic_, string());
  nodeHandle_.param("enable_visibility_cleanup", map_.enableVisibilityCleanup_, true);
  nodeHandle_.param("scanning_duration", map_.scanningDuration_, 1.0);

  float obstacle_threshold = 0.7;
  length_ = length(0) / resolution;
  resolution_ = resolution;

  Init_GPU_elevationmap(length_, resolution_, map_.mahalanobisDistanceThreshold_, obstacle_threshold);
 
  // SensorProcessor parameters.
  string sensorType;
  nodeHandle_.param("sensor_processor/type", sensorType, string("structured_light"));
  if (sensorType == "structured_light") {
    sensorProcessor_.reset(new StructuredLightSensorProcessor(nodeHandle_, transformListener_));
  } else if (sensorType == "stereo") {
    sensorProcessor_.reset(new StereoSensorProcessor(nodeHandle_, transformListener_));
  } else if (sensorType == "laser") {
    sensorProcessor_.reset(new LaserSensorProcessor(nodeHandle_, transformListener_));
  } else if (sensorType == "perfect") {
    sensorProcessor_.reset(new PerfectSensorProcessor(nodeHandle_, transformListener_));
  } else {
    ROS_ERROR("The sensor type %s is not available.", sensorType.c_str());
  }

  if (!sensorProcessor_->readParameters()) return false;
  if (!robotMotionMapUpdater_.readParameters()) return false;

  return true;
}

bool ElevationMapping::initialize()
{
  ROS_INFO("Elevation mapping node initializing ... ");

  Duration(1.0).sleep(); // Need this to get the TF caches fill up.
  resetMapUpdateTimer();
  
  ROS_INFO("Done.");
  return true;
}


void ElevationMapping::processpoints(pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr pointCloud)
{ 
  std::cout << "processpoints start" << std::endl;

  int point_num = pointCloud->size();
  int point_index[point_num];
  float point_height[point_num];
  float point_var[point_num];
  //raw_cells *cells_info;
  //cells_info = (raw_cells*) cells_void;
  
 
  Eigen::Matrix<double, 6, 6> PoseCovariance;
  PoseCovariance.setZero();  

  PointCloud<PointXYZRGB>::Ptr pointProcessed(new PointCloud<PointXYZRGB>);

  if (!this->sensorProcessor_->process(pointCloud, PoseCovariance, pointProcessed, point_index, point_height, point_var)) {
    ROS_ERROR("Point cloud could not be processed.");
    this->resetMapUpdateTimer();
  }


  Fuse(length_, point_num, point_index, point_height, point_var);

  std::cout << "processpoints end" << std::endl;
  //double p11 = (ros::Time::now () - begin_time).toSec ();
  //
   //<< "processpoints time1 is :" << p11  << std::endl;
  //map_.updatepointsinfo(pointProcessed, measurementVariances, lastPointCloudUpdateTime_, cells_info);
  
}

void ElevationMapping::processmapcells()
{
  std::cout << "processmapcells start" << std::endl;

  
  if (!this->updatePrediction(this->lastPointCloudUpdateTime_)) {
    ROS_ERROR("Updating process noise failed.");
    this->resetMapUpdateTimer();
    return;
  }

  std::cout << "processmapcells end" << std::endl;
}

void ElevationMapping::pointCloudCallback(const sensor_msgs::PointCloud2::ConstPtr& rawPointCloud)
{
  ros::Time begin_time = ros::Time::now ();
 
  stopMapUpdateTimer();
  pcl::PCLPointCloud2 pcl_pc;
  pcl_conversions::toPCL(*rawPointCloud, pcl_pc);

  PointCloud<PointXYZRGB>::Ptr pointCloud(new PointCloud<PointXYZRGB>);
  pcl::fromPCLPointCloud2(pcl_pc, *pointCloud); 
  lastPointCloudUpdateTime_.fromNSec(1000 * pointCloud->header.stamp);
  
  // pcl::PassThrough<pcl::PointXYZRGB> pass;
  // pass.setInputCloud (pointCloud);            //设置输入点云
  // pass.setFilterFieldName ("x");         //设置过滤时所需要点云类型的Z字段
  // pass.setFilterLimits (-10, 10);        //设置在过滤字段的范围
  // pass.filter (*pointCloud);

  // pass.setInputCloud (pointCloud);
  // pass.setFilterFieldName ("y");         //设置过滤时所需要点云类型的Z字段
  // pass.setFilterLimits (-15, 15);        //设置在过滤字段的范围
  // pass.filter (*pointCloud);


  ROS_INFO("ElevationMap received a point cloud (%i points) for elevation mapping.", static_cast<int>(pointCloud->size()));
  


  updatepointsMapLocation();
  updateMapLocation();


  processpoints(pointCloud);
  processmapcells();
  // std::thread t1(&ElevationMapping::processpoints, this, pointCloud);
  // std::thread t2(&ElevationMapping::processmapcells, this);
  // t1.join();
  // t2.join();  

  //std::cout << "max_height" << cells_info[0].max_ele << std::endl;
  
  float elevation[length_ * length_];
  float rough[length_ * length_];
  float slope[length_ * length_];
  float traver[length_ * length_];
  float var[length_ * length_];
  Map_feature(length_, elevation, var, rough, slope, traver);

  map_.show(length_, elevation, var, rough, slope, traver);
  Raytracing(length_);

  double p12 = (ros::Time::now () - begin_time).toSec ();
  std::cout << "points callback time is :" << p12  << std::endl;
  std::cout << std::endl;
   
}



bool ElevationMapping::updatePrediction(const ros::Time& time)
{

  if (ignoreRobotMotionUpdates_) return true;

  ROS_DEBUG("Updating map with latest prediction from time %f.", robotPoseCache_.getLatestTime().toSec());
 
  if (time + timeTolerance_ < map_.getTimeOfLastUpdate()) {
   // map_.ElevationMap::getRawGridMap().setTimestamp(0);
  }
  if (time + timeTolerance_ < map_.getTimeOfLastUpdate()) {
    ROS_ERROR("Requested update with time stamp %f, but time of last update was %f.", time.toSec(), map_.getTimeOfLastUpdate().toSec());
    return false;
  } else if (time < map_.getTimeOfLastUpdate()) {
    ROS_DEBUG("Requested update with time stamp %f, but time of last update was %f. Ignoring update.", time.toSec(), map_.getTimeOfLastUpdate().toSec());
    return true;
  }


  geometry_msgs::Pose Tf_robotpose;

  Tf_robotpose.position.x = sensorProcessor_->M2StransformTf.getOrigin().x();
	Tf_robotpose.position.y = sensorProcessor_->M2StransformTf.getOrigin().y();
	Tf_robotpose.position.z = sensorProcessor_->M2StransformTf.getOrigin().z();
	Tf_robotpose.orientation.x = sensorProcessor_->M2StransformTf.getRotation().getX();
  Tf_robotpose.orientation.y = sensorProcessor_->M2StransformTf.getRotation().getY();
  Tf_robotpose.orientation.z = sensorProcessor_->M2StransformTf.getRotation().getZ();
  Tf_robotpose.orientation.w = sensorProcessor_->M2StransformTf.getRotation().getW();
  
  robot_x = Tf_robotpose.position.x;
  robot_y = Tf_robotpose.position.y;
  robot_height = Tf_robotpose.position.z;
  HomTransformQuatD robotPose;
  convertFromRosGeometryMsg(Tf_robotpose, robotPose);
  if(Tf_robotpose.position.x == 0 && Tf_robotpose.position.y == 0)
    return true;

  Eigen::Matrix<double, 6, 6> robotPoseCovariance;
  robotPoseCovariance.setZero();  
  // Covariance is stored in row-major in ROS: http://docs.ros.org/api/geometry_msgs/html/msg/PoseWithCovariance.html

  // Compute map variance update from motio n prediction.
  robotMotionMapUpdater_.update(map_, robotPose, robotPoseCovariance, time);
  
  return true;
}

bool ElevationMapping::updatepointsMapLocation()
{
  ROS_DEBUG("Elevation map is checked for relocalization.");

  geometry_msgs::PointStamped trackPoint;
  trackPoint.header.frame_id = trackPointFrameId_;
  trackPoint.header.stamp = ros::Time(0);
  convertToRosGeometryMsg(trackPoint_, trackPoint.point);
  geometry_msgs::PointStamped trackPointTransformed;

  try {
    transformListener_.transformPoint(map_.getFrameId(), trackPoint, trackPointTransformed);
  } catch (TransformException &ex) {
    ROS_ERROR("%s", ex.what());
    return false;
  }

  trackPointTransformed_x = trackPointTransformed.point.x;
  trackPointTransformed_y = trackPointTransformed.point.y;
  trackPointTransformed_z = trackPointTransformed.point.z;
}


bool ElevationMapping::updateMapLocation()
{
  
  float current_p[3];
  current_p[0] = trackPointTransformed_x;
  current_p[1] = trackPointTransformed_y;
  current_p[2] = trackPointTransformed_z;

  //for(int i = 0; )  
  std::cout << "p_x:" << current_p[0] << " p_y:" << current_p[1] << " p_z:" << current_p[2] << std::endl;

  int d_startindex[2];
  float d_position[2];

  Move(current_p , resolution_,  length_, d_position, d_startindex);
  
  grid_map::Index M_startindex;
  grid_map::Position M_position;

  

  M_startindex.x() = d_startindex[0];
  M_startindex.y() = d_startindex[1];

  M_position.x() = d_position[0];
  M_position.y() = d_position[1];
  
  std::cout << "M_x:" << M_position.x() << " M_y:" <<  M_position.y() << std::endl;
  // Index M_startindex
  // Position M_position


  //std::cout << "Move position:" << M_position << std::endl;
  map_.move(M_startindex, M_position);
  return true;
}




void ElevationMapping::resetMapUpdateTimer()
{
  mapUpdateTimer_.stop();
  Duration periodSinceLastUpdate = ros::Time::now() - map_.getTimeOfLastUpdate();
  if (periodSinceLastUpdate > maxNoUpdateDuration_) periodSinceLastUpdate.fromSec(0.0);
  mapUpdateTimer_.setPeriod(maxNoUpdateDuration_ - periodSinceLastUpdate);
  mapUpdateTimer_.start();
}

void ElevationMapping::stopMapUpdateTimer()
{
  mapUpdateTimer_.stop();
}

} /* namespace */
