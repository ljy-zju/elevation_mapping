/*
 * Pointcloudtogrid.cpp
 *
 *  Created on: Aug 1, 2019
 *      Author: Peter XXC
 *	 Institute: ZJU, Robotics 104
 */

/*!
 * Example Usage(1) - Set map scale
 * 
 *  PointcloudToGrid point2Grid_;
 *  grid_map::Length length_p2g;
 *  length_p2g.x() = 12;
 *  length_p2g.y() = 12;
 *  double resolution_p2g = 1;
 *  point2Grid_.setScale(length_p2g, resolution_p2g);
 *      
 * Example Usage(2) - Process pointcloud and variances
 *
 *  PointcloudToGrid point2Grid_;
 *  float highest;
 *  grid_map::Length length_p2g;
 *  length_p2g.x() = 12;
 *  length_p2g.y() = 12;
 *  double resolution_p2g = 1;
 *  point2Grid_.setScale(length_p2g, resolution_p2g);
 *  
 *  int grid_num = (length_p2g.x()/resolution_p2g) * (length_p2g.y()/resolution_p2g);
 *  Cell_feature cell_1[grid_num];
 *  point2Grid_.pointCloudProcess(pointCloudProcessed, variances, cell_1);
 *  highest = cell_1[1].highest;
 */

/****** Usage Example for publish grid map with processed cell struct ******/
//   在pointCloudCallback函数中
//   pcl::PointCloud<pcl::PointXYZRGB>::Ptr point_in_robot_tf(new pcl::PointCloud<pcl::PointXYZRGB> ());
//   pcl::transformPointCloud(*pointCloudProcessed, *point_in_robot_tf, Eigen::Affine3d(sensorProcessor_->transformationSensorToMap_.inverse()));

//   int grid_num = (length_p2g.x()/resolution_p2g) * (length_p2g.y()/resolution_p2g);
//   Cell_feature cell_1[grid_num];

//   PointcloudToGrid point2Grid_;
//   point2Grid_.setScale(length_p2g, resolution_p2g);
//   point2Grid_.pointCloudProcess(point_in_robot_tf, pThis->measurementVariances, cell_1);
  
//   // std::cout << &point2Grid_ << std::endl;
//   // for(int i = 0; i<120*120; i++){
//   //   if(cell_1[i].flag == 1)
//   //     ROS_ERROR("lowest:[%f], highest[%f]",cell_1[i].lowest, cell_1[i].highest);
//   // }

//   if (nodeHandle_.ok()) {
//     int index = 0;
//     // Add cell point features: high z and low z to the map layer
//     for (GridMapIterator it(processed_map); !it.isPastEnd(); ++it) {
//             grid_map::Position position;
//             processed_map.getPosition(*it, position);
//             ROS_ERROR("POSITION: {%f, %f}", position.x(), position.y());
//             processed_map.at("highest", *it) = cell_1[index].highest;
//             processed_map.at("lowest", *it) = cell_1[index].lowest;
//             index ++;
//     }

//     grid_map_msgs::GridMap message;
//     GridMapRosConverter::toMessage(processed_map, message);
//     processed_points.publish(message);
//     ROS_INFO_THROTTLE(1.0, "Grid map (timestamp %f) published.", message.info.header.stamp.toSec());
//   }
/****** Usage Example for publish grid map with processed cell struct ******/
  


// Elevation Mapping
#include "elevation_mapping/ElevationMap.hpp"
#include "elevation_mapping/RobotMotionMapUpdater.hpp"
#include "elevation_mapping/sensor_processors/SensorProcessorBase.hpp"
#include "elevation_mapping/WeightedEmpiricalCumulativeDistributionFunction.hpp"
#include "elevation_mapping/Pointcloudtogrid.hpp"

// Grid Map
#include <grid_map_msgs/GetGridMap.h>
#include <grid_map_msgs/ProcessFile.h>
#include "grid_map_core/TypeDefs.hpp"
#include "grid_map_core/SubmapGeometry.hpp"
#include "grid_map_core/BufferRegion.hpp"

// Eigen
#include <Eigen/Core>
#include <Eigen/Geometry>

// PCL
#include <pcl/conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/PCLPointCloud2.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/filters/voxel_grid.h>

// ROS
#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <message_filters/cache.h>
#include <message_filters/subscriber.h>
#include <tf/transform_listener.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <std_srvs/Empty.h>

// Boost
#include <boost/thread.hpp>

// Eigen
#include <Eigen/Core>
#include <Eigen/Geometry>

using namespace grid_map;
using namespace pcl;

namespace elevation_mapping{
    
class PointcloudToGrid;

PointcloudToGrid::PointcloudToGrid()
{
    length_.setZero();
    resolution_ = 0.0;
    
    grid_num.x() = 0.0;
    grid_num.y() = 0.0;
}

PointcloudToGrid::~PointcloudToGrid()
{
}

void PointcloudToGrid::setScale(const Length& length, const double resolution)
{
    assert(length(0) > 0.0);
    assert(length(1) > 0.0);
    assert(resolution > 0.0);

    resolution_ = resolution;
    length_.x() = length.x();
    length_.y() = length.y();
    
    grid_num.x() = length_.x()/resolution_;
    grid_num.y() = length_.y()/resolution_;

    return;
}

void PointcloudToGrid::pointCloudProcess(const pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr &InputCloud, Eigen::VectorXf& variances, struct Cell_feature cell_with_pos[])
{
    int grid_number = grid_num.x()*grid_num.y();
    //Cell_feature* cell_with_pos = new Cell_feature[grid_number];
    //Cell_feature cell_with_pos[grid_number];

    ROS_INFO("PointcloudToGrid is processing Pointcloud.");
    ROS_ERROR("Processing: %d, %d ",grid_num.x(), grid_num.y());

    int index = 0;
    for (size_t i = 0; i < InputCloud->points.size(); ++i) {
        PointXYZRGB pt;
        pt.x = InputCloud->points[i].x;
        pt.y = InputCloud->points[i].y;
        pt.z = InputCloud->points[i].z;

        int cell_pos_x, cell_pos_y, cell_pos;
        cell_pos_x = floor(-(pt.x - length_.x()/2)/resolution_);
        cell_pos_y = floor(-(pt.y - length_.y()/2)/resolution_);

        if(cell_pos_x >= 0 && cell_pos_y >= 0 && cell_pos_x < grid_num.x() && cell_pos_y < grid_num.y()){
            cell_pos = cell_pos_x  + cell_pos_y * grid_num.x();
        }else{
            cell_pos = -1;
        }
    ROS_ERROR("point [%f, %f, %f], cell_pos: %d, %d, cell %d",
                pt.x, pt.y, pt.z, cell_pos_x, cell_pos_y, cell_pos);

        float tmp_highest = cell_with_pos[cell_pos].highest;
        float tmp_lowest = cell_with_pos[cell_pos].lowest;

        if(cell_with_pos[cell_pos].flag == NOT_OCCUPIED && cell_pos >= 0  && cell_pos <= grid_number){
            cell_with_pos[cell_pos].highest = pt.z;
            cell_with_pos[cell_pos].lowest = pt.z;
            cell_with_pos[cell_pos].h_var = variances(i);
            cell_with_pos[cell_pos].l_var = variances(i);
            cell_with_pos[cell_pos].flag = OCCUPIED;
        }else if(pt.z > tmp_highest && cell_pos >= 0 && cell_pos <= grid_number && cell_with_pos[cell_pos].flag == OCCUPIED){
            cell_with_pos[cell_pos].highest = pt.z;
            cell_with_pos[cell_pos].h_var = variances(i);
        }else if(pt.z < tmp_lowest && cell_pos >= 0 && cell_pos <= grid_number && cell_with_pos[cell_pos].flag == OCCUPIED){
            cell_with_pos[cell_pos].lowest = pt.z;
            cell_with_pos[cell_pos].l_var = variances(i);
        }
    }
    
}

}