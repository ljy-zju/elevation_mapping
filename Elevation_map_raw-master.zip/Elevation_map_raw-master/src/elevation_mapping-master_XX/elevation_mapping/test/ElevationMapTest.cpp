/*
 * ElevationMapTest.cpp
 *
 *  Created on: Nov 27, 2015
 *      Author: Péter Fankhauser
 *	 Institute: ETH Zurich, ANYbotics
 */

#include "elevation_mapping/ElevationMap.hpp"
#include "grid_map_core/GridMap.hpp"

#include <ros/ros.h>

// gtest
#include <gtest/gtest.h>

using namespace elevation_mapping;
using namespace grid_map;

TEST(ElevationMap, Test)
{
//  ros::M_string remappings;
//  ros::init(remappings, "test_elevation_mapping");
//  ros::NodeHandle nodeHandle("~");
//  ElevationMap map(nodeHandle);
//  map.setGeometry(Length(1.0, 1.0), 0.01, Position(0.0, 0.0));
}

